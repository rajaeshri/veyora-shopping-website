import fs from 'fs';
import path from 'path';

console.log('=== VEYORA - FINAL CODE REVIEW ===\n');

const srcDir = './src';
let issues = [];
let warnings = [];

function checkFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  const fileName = path.relative('.', filePath);

  // Check 1: Debug code
  if (content.includes('console.log') || content.includes('debugger')) {
    issues.push(`${fileName}: Contains debug code (console.log/debugger)`);
  }

  // Check 2: Unused imports (common patterns)
  const importLines = content.match(/^import .* from .*;?$/gm) || [];
  importLines.forEach(line => {
    const match = line.match(/import\s+(?:{\s*([^}]+)\s*}|(\w+))/);
    if (match) {
      const names = (match[1] || match[2]).split(',').map(s => s.trim());
      names.forEach(name => {
        const nameRegex = new RegExp(`\\b${name}\\b`);
        if (!content.match(nameRegex) || content.match(nameRegex).length <= 1) {
          // Could be unused, but not always (React, Fragment, etc. are ok)
          if (!['React', 'Fragment', 'Component', 'PureComponent', 'StrictMode'].includes(name)) {
            // Likely unused
          }
        }
      });
    }
  });

  // Check 3: Hardcoded secrets
  if (content.match(/['"][\w]{8,}['"]/) && (
    content.includes('API_KEY') || 
    content.includes('SECRET') || 
    content.includes('PASSWORD') ||
    content.includes('TOKEN')
  )) {
    issues.push(`${fileName}: Possible hardcoded secrets`);
  }

  // Check 4: TODO/FIXME comments
  if (content.includes('TODO') || content.includes('FIXME') || content.includes('XXX')) {
    const count = (content.match(/TODO|FIXME|XXX/g) || []).length;
    warnings.push(`${fileName}: Contains ${count} TODO/FIXME comments`);
  }

  // Check 5: Very long functions (>100 lines)
  const functions = content.match(/function\s+\w+\s*\([\s\S]*?\n\}/g) || [];
  functions.forEach(fn => {
    const lines = fn.split('\n').length;
    if (lines > 100) {
      warnings.push(`${fileName}: Function exceeds 100 lines (${lines} lines)`);
    }
  });

  // Check 6: Direct DOM manipulation
  if (content.includes('document.getElementById') || 
      content.includes('querySelector') ||
      content.includes('innerHTML')) {
    warnings.push(`${fileName}: Contains direct DOM manipulation`);
  }

  // Check 7: Inline styles in JSX
  const inlineStyles = (content.match(/style\s*=\s*{{/g) || []).length;
  if (inlineStyles > 5) {
    warnings.push(`${fileName}: Multiple inline styles (${inlineStyles} instances)`);
  }
}

function getAllFiles(dir) {
  let results = [];
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      results = results.concat(getAllFiles(filePath));
    } else if (filePath.endsWith('.jsx') || filePath.endsWith('.js')) {
      results.push(filePath);
    }
  });
  
  return results;
}

// Run checks
const files = getAllFiles(srcDir);
files.forEach(checkFile);

// Summary
console.log('📊 CODE REVIEW SUMMARY\n');
console.log(`Total files reviewed: ${files.length}`);
console.log(`Total lines of code: ~${files.reduce((sum, f) => {
  const content = fs.readFileSync(f, 'utf8');
  return sum + content.split('\n').length;
}, 0)}`);

console.log(`\n✓ Files checked:`);
files.forEach(f => console.log(`  - ${path.relative('.', f)}`));

if (issues.length === 0 && warnings.length === 0) {
  console.log('\n✅ NO ISSUES FOUND - Code is clean and production-ready!');
} else {
  if (issues.length > 0) {
    console.log(`\n❌ ISSUES (${issues.length}):`);
    issues.forEach(issue => console.log(`  - ${issue}`));
  }
  
  if (warnings.length > 0) {
    console.log(`\n⚠️  WARNINGS (${warnings.length}):`);
    warnings.forEach(warning => console.log(`  - ${warning}`));
  }
}

console.log('\n✅ FINAL CODE REVIEW COMPLETE\n');
