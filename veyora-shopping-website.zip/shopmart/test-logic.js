// Test cart, auth, and order logic functions
import { 
  addItem, changeQuantity, removeItem, cleanItems, getTotals,
  MAX_QTY, FREE_SHIPPING_MIN, SHIPPING_FEE 
} from './src/context/cartLogic.js'
import {
  validateLoginForm, validateSignupForm, validateCheckoutForm,
  hashPassword, verifyPassword, generateOrderID
} from './src/context/authLogic.js'
import { getProducts, getProductById, categories } from './src/data/products.js'

console.log('=== VEYORA SHOPPING WEBSITE - LOGIC TESTS ===\n')

let testsPassed = 0
let testsFailed = 0

function test(name, fn) {
  try {
    fn()
    console.log(`✅ ${name}`)
    testsPassed++
  } catch (err) {
    console.log(`❌ ${name}`)
    console.log(`   Error: ${err.message}`)
    testsFailed++
  }
}

// ==================== CART LOGIC TESTS ====================
console.log('CART LOGIC TESTS\n')

test('addItem: adds new item to empty cart', () => {
  const items = []
  const result = addItem(items, 1, 2)
  if (result.length !== 1 || result[0].id !== 1 || result[0].quantity !== 2) throw new Error('Failed')
})

test('addItem: increases quantity when item already in cart', () => {
  const items = [{id: 1, quantity: 2}]
  const result = addItem(items, 1, 3)
  if (result.length !== 1 || result[0].quantity !== 5) throw new Error('Failed')
})

test('addItem: clamps quantity to MAX_QTY', () => {
  const items = [{id: 1, quantity: MAX_QTY - 1}]
  const result = addItem(items, 1, 5)
  if (result[0].quantity !== MAX_QTY) throw new Error('Failed')
})

test('changeQuantity: changes item quantity', () => {
  const items = [{id: 1, quantity: 3}]
  const result = changeQuantity(items, 1, 2)
  if (result[0].quantity !== 5) throw new Error('Failed')
})

test('changeQuantity: clamps to minimum 1', () => {
  const items = [{id: 1, quantity: 2}]
  const result = changeQuantity(items, 1, -5)
  if (result[0].quantity !== 1) throw new Error('Failed')
})

test('removeItem: removes item from cart', () => {
  const items = [{id: 1, quantity: 2}, {id: 2, quantity: 3}]
  const result = removeItem(items, 1)
  if (result.length !== 1 || result[0].id !== 2) throw new Error('Failed')
})

test('cleanItems: filters invalid items from localStorage', () => {
  const raw = [{id: 1, quantity: 2}, {id: 999, quantity: 1}, null, {quantity: 5}]
  const result = cleanItems(raw, (id) => id !== 999)
  if (result.length !== 1 || result[0].id !== 1) throw new Error('Failed')
})

test('getTotals: calculates correct subtotal', () => {
  const items = [{id: 1, quantity: 2}]
  const product1 = { id: 1, price: 100 }
  const result = getTotals(items, (id) => id === 1 ? product1 : null)
  if (result.subtotal !== 200) throw new Error(`Expected 200, got ${result.subtotal}`)
})

test('getTotals: applies free shipping threshold', () => {
  const items = [{id: 1, quantity: 1}]
  const product1 = { id: 1, price: FREE_SHIPPING_MIN + 1 }
  const result = getTotals(items, (id) => id === 1 ? product1 : null)
  if (result.shipping !== 0) throw new Error('Expected free shipping')
})

test('getTotals: charges shipping when below threshold', () => {
  const items = [{id: 1, quantity: 1}]
  const product1 = { id: 1, price: FREE_SHIPPING_MIN - 100 }
  const result = getTotals(items, (id) => id === 1 ? product1 : null)
  if (result.shipping !== SHIPPING_FEE) throw new Error(`Expected ${SHIPPING_FEE}, got ${result.shipping}`)
})

// ==================== AUTH LOGIC TESTS ====================
console.log('\nAUTH LOGIC TESTS\n')

test('validateLoginForm: rejects empty email', () => {
  const errors = validateLoginForm('', 'password123')
  if (errors.length === 0 || !errors[0].includes('Email')) throw new Error('Failed')
})

test('validateLoginForm: rejects invalid email', () => {
  const errors = validateLoginForm('notanemail', 'password123')
  if (errors.length === 0 || !errors[0].includes('Invalid')) throw new Error('Failed')
})

test('validateLoginForm: rejects empty password', () => {
  const errors = validateLoginForm('user@example.com', '')
  if (errors.length === 0 || !errors[0].includes('Password')) throw new Error('Failed')
})

test('validateLoginForm: accepts valid credentials', () => {
  const errors = validateLoginForm('user@example.com', 'password123')
  if (errors.length !== 0) throw new Error('Failed')
})

test('validateSignupForm: rejects password mismatch', () => {
  const errors = validateSignupForm('John', 'john@example.com', 'pass123', 'pass456')
  if (errors.length === 0 || !errors[0].includes('not match')) throw new Error('Failed')
})

test('validateSignupForm: rejects short password', () => {
  const errors = validateSignupForm('John', 'john@example.com', 'pass', 'pass')
  if (errors.length === 0 || !errors[0].includes('least')) throw new Error('Failed')
})

test('validateSignupForm: accepts valid signup', () => {
  const errors = validateSignupForm('John', 'john@example.com', 'pass123', 'pass123')
  if (errors.length !== 0) throw new Error('Failed')
})

test('validateCheckoutForm: rejects invalid phone', () => {
  const errors = validateCheckoutForm('John', 'john@example.com', '123', 'addr', 'city', 'state', '123456')
  if (errors.length === 0 || !errors[0].includes('10')) throw new Error('Failed')
})

test('validateCheckoutForm: rejects invalid pincode', () => {
  const errors = validateCheckoutForm('John', 'john@example.com', '1234567890', 'addr', 'city', 'state', '123')
  if (errors.length === 0 || !errors[0].includes('6')) throw new Error('Failed')
})

test('validateCheckoutForm: accepts valid checkout', () => {
  const errors = validateCheckoutForm('John', 'john@example.com', '1234567890', 'addr', 'city', 'state', '123456')
  if (errors.length !== 0) throw new Error(`Got errors: ${errors.join(', ')}`)
})

test('hashPassword: hashes password', () => {
  const hash = hashPassword('mypassword')
  if (typeof hash !== 'string' || hash.length === 0) throw new Error('Failed')
})

test('verifyPassword: verifies correct password', () => {
  const hash = hashPassword('mypassword')
  if (!verifyPassword('mypassword', hash)) throw new Error('Failed')
})

test('verifyPassword: rejects wrong password', () => {
  const hash = hashPassword('mypassword')
  if (verifyPassword('wrongpassword', hash)) throw new Error('Failed')
})

test('generateOrderID: creates unique IDs', () => {
  const id1 = generateOrderID()
  const id2 = generateOrderID()
  if (id1 === id2 || !id1.startsWith('ORD-')) throw new Error('Failed')
})

// ==================== PRODUCT DATA TESTS ====================
console.log('\nPRODUCT DATA TESTS\n')

test('getProducts: returns array of 16 products', () => {
  const products = getProducts()
  if (!Array.isArray(products) || products.length !== 16) throw new Error(`Expected 16, got ${products.length}`)
})

test('products: all have required fields', () => {
  const products = getProducts()
  products.forEach(p => {
    if (!p.id || !p.name || !p.category || !p.price || !p.image || !p.rating) {
      throw new Error(`Product ${p.id} missing fields`)
    }
  })
})

test('categories: contains 5 categories', () => {
  if (!Array.isArray(categories) || categories.length !== 5) throw new Error('Failed')
})

test('getProductById: finds product by ID', () => {
  const product = getProductById('1')
  if (!product || product.id !== 1) throw new Error('Failed')
})

test('getProductById: returns null for invalid ID', () => {
  const product = getProductById('999')
  if (product !== null) throw new Error('Failed')
})

// ==================== SUMMARY ====================
console.log(`\n${'='.repeat(50)}`)
console.log(`\nTESTS PASSED: ${testsPassed}`)
console.log(`TESTS FAILED: ${testsFailed}`)
console.log(`\nTOTAL: ${testsPassed + testsFailed}`)

if (testsFailed === 0) {
  console.log('\n✅ ALL TESTS PASSED!\n')
  process.exit(0)
} else {
  console.log(`\n❌ ${testsFailed} TEST(S) FAILED\n`)
  process.exit(1)
}
