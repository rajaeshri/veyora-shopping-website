import fs from 'fs';
import path from 'path';

console.log('=== Veyora Shopping Website - Code Audit ===\n');

const srcDir = './src';
let issues = [];
let warnings = [];

// 1. Check all .jsx and .js files for syntax
function checkSyntax() {
  console.log('1. CHECKING SYNTAX...\n');
  const files = getAllFiles(srcDir, ['.jsx', '.js']);
  
  files.forEach(file => {
    try {
      const content = fs.readFileSync(file, 'utf8');
      
      // Check for common syntax errors
      if (content.includes('import ') && !content.includes('from')) {
        warnings.push(`${file}: Incomplete import statement detected`);
      }
      
      // Check for JSX issues
      if (file.endsWith('.jsx')) {
        if (!content.includes('export') && !content.includes('from')) {
          warnings.push(`${file}: No exports detected`);
        }
      }
      
      console.log(`✓ ${file}`);
    } catch (err) {
      issues.push(`${file}: ${err.message}`);
    }
  });
  
  console.log(`\n✓ Syntax check complete\n`);
}

// 2. Check imports
function checkImports() {
  console.log('2. CHECKING IMPORTS...\n');
  const files = getAllFiles(srcDir, ['.jsx', '.js']);
  
  files.forEach(file => {
    const content = fs.readFileSync(file, 'utf8');
    const importMatches = content.match(/import\s+(?:{[^}]+}|\w+)\s+from\s+['"][^'"]+['"]/g);
    
    if (importMatches) {
      importMatches.forEach(imp => {
        // Check React imports are correct
        if (imp.includes('react')) {
          if (!imp.includes('React')) {
            warnings.push(`${file}: React import style - consider importing React`);
          }
        }
        console.log(`  ${file}: ${imp}`);
      });
    }
  });
  
  console.log('\n✓ Import check complete\n');
}

// 3. Check for unused variables and functions
function checkUnusedCode() {
  console.log('3. CHECKING FOR UNUSED CODE...\n');
  
  const files = getAllFiles(srcDir, ['.jsx', '.js']);
  files.forEach(file => {
    const content = fs.readFileSync(file, 'utf8');
    
    // Check for unused destructured variables
    const destructures = content.match(/const\s+{[^}]+}\s*=/g);
    if (destructures) {
      destructures.forEach(d => {
        const vars = d.replace(/const\s+{|}|=|;/g, '').split(',').map(v => v.trim());
        vars.forEach(v => {
          if (v && !content.includes(v)) {
            warnings.push(`${file}: Possibly unused variable: ${v}`);
          }
        });
      });
    }
    
    // Check for undefined functions
    const functionCalls = content.match(/\b[a-zA-Z_]\w*\s*\(/g);
    if (functionCalls) {
      functionCalls.forEach(call => {
        const funcName = call.replace(/\s*\(/, '');
        const isBuiltin = ['map', 'filter', 'reduce', 'forEach', 'useState', 'useEffect', 'useContext', 'useParams', 'navigate', 'console', 'setStorageItem', 'getStorageItem'].includes(funcName);
        
        if (!isBuiltin && !content.includes(`function ${funcName}`) && !content.includes(`const ${funcName}`)) {
          if (!['if', 'for', 'while', 'switch', 'return'].includes(funcName)) {
            // This might be fine if it's from an import
          }
        }
      });
    }
  });
  
  console.log('✓ Unused code check complete\n');
}

// 4. Check for missing keys in lists
function checkMissingKeys() {
  console.log('4. CHECKING FOR MISSING KEYS IN LISTS...\n');
  
  const files = getAllFiles(srcDir, ['.jsx']);
  files.forEach(file => {
    const content = fs.readFileSync(file, 'utf8');
    
    // Look for .map() calls in JSX
    const mapCalls = content.match(/\.map\s*\(\s*[a-zA-Z0-9_,\s]*\s*=>\s*\(/g);
    if (mapCalls) {
      // Check if key prop is present
      if (content.includes('.map') && !content.includes('key=')) {
        warnings.push(`${file}: .map() found but no key prop detected - check for proper key usage`);
      }
    }
  });
  
  console.log('✓ Key check complete\n');
}

// 5. Check for console.logs
function checkConsoleLogs() {
  console.log('5. CHECKING FOR DEBUG CONSOLE LOGS...\n');
  
  const files = getAllFiles(srcDir, ['.jsx', '.js']);
  files.forEach(file => {
    const content = fs.readFileSync(file, 'utf8');
    
    if (content.includes('console.log') || content.includes('console.error')) {
      warnings.push(`${file}: Console log/error statement found - should be removed for production`);
    }
  });
  
  console.log('✓ Console check complete\n');
}

// 6. Check routing
function checkRouting() {
  console.log('6. CHECKING ROUTING...\n');
  
  const appFile = fs.readFileSync('./src/App.jsx', 'utf8');
  const routes = appFile.match(/path="[^"]+"/g);
  
  if (routes) {
    console.log('Routes found:');
    routes.forEach(route => console.log(`  ${route}`));
  }
  
  console.log('\n✓ Routing check complete\n');
}

// 7. Check for potential runtime errors
function checkRuntimeErrors() {
  console.log('7. CHECKING FOR POTENTIAL RUNTIME ERRORS...\n');
  
  const pages = [
    './src/pages/Login.jsx',
    './src/pages/Signup.jsx',
    './src/pages/Cart.jsx',
    './src/pages/Checkout.jsx'
  ];
  
  pages.forEach(file => {
    if (fs.existsSync(file)) {
      const content = fs.readFileSync(file, 'utf8');
      
      // Check for unhandled async/await
      if (content.includes('await') && !content.includes('try')) {
        warnings.push(`${file}: Async/await without try-catch block`);
      }
      
      // Check for .then() without .catch()
      if (content.includes('.then(') && !content.includes('.catch(')) {
        warnings.push(`${file}: Promise .then() without .catch() handler`);
      }
      
      // Check for direct DOM manipulation
      if (content.includes('document.getElementById') || content.includes('querySelector')) {
        warnings.push(`${file}: Direct DOM manipulation detected - use React refs instead`);
      }
      
      console.log(`✓ ${file}`);
    }
  });
  
  console.log('\n✓ Runtime error check complete\n');
}

// Helper function to get all files
function getAllFiles(dir, extensions) {
  let results = [];
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    
    if (stat.isDirectory()) {
      results = results.concat(getAllFiles(filePath, extensions));
    } else if (extensions.some(ext => filePath.endsWith(ext))) {
      results.push(filePath);
    }
  });
  
  return results;
}

// Run all checks
try {
  checkSyntax();
  checkImports();
  checkUnusedCode();
  checkMissingKeys();
  checkConsoleLogs();
  checkRouting();
  checkRuntimeErrors();
  
  console.log('\n=== AUDIT SUMMARY ===\n');
  console.log(`Critical Issues: ${issues.length}`);
  console.log(`Warnings: ${warnings.length}\n`);
  
  if (issues.length > 0) {
    console.log('CRITICAL ISSUES:');
    issues.forEach(issue => console.log(`  ❌ ${issue}`));
    console.log();
  }
  
  if (warnings.length > 0) {
    console.log('WARNINGS:');
    warnings.forEach(warning => console.log(`  ⚠️  ${warning}`));
    console.log();
  }
  
  if (issues.length === 0 && warnings.length === 0) {
    console.log('✅ No critical issues or warnings found!\n');
  }
} catch (err) {
  console.error('Audit failed:', err.message);
}
