# GitHub Setup Guide

## Step-by-Step GitHub Repository Setup

### Prerequisites
- GitHub account (free at https://github.com)
- Git installed locally
- Repository cloned or ready to push

### Steps to Create Repository

#### 1. Create New Repository on GitHub

1. Log in to GitHub
2. Click "+" in top right → "New repository"
3. Repository name: `veyora-shopping`
4. Description: "A modern React e-commerce shopping website"
5. Visibility: Public (for portfolio)
6. Click "Create repository"

#### 2. Initialize Local Repository

```bash
cd /home/claude/shopmart
git init
git add .
git commit -m "Initial commit: Complete Veyora shopping website with full features"
```

#### 3. Add Remote and Push

```bash
git branch -M main
git remote add origin https://github.com/yourusername/veyora-shopping.git
git push -u origin main
```

### Repository Contents

#### ✅ Files to Include
```
veyora-shopping/
├── src/                          (All source code)
├── package.json                  (Dependencies)
├── vite.config.js               (Build config)
├── index.html                   (Entry point)
├── README.md                    (Project docs)
├── DEPLOYMENT.md                (Deployment guide)
├── FINAL_TEST_REPORT_STEP9.md   (Test results)
├── .gitignore                   (Git ignore rules)
├── vercel.json                  (Vercel config)
├── netlify.toml                 (Netlify config)
└── GITHUB_SETUP.md              (This file)
```

#### ❌ Files to Exclude (via .gitignore)
```
node_modules/
dist/
build/
.env
.env.local
npm-debug.log
.vscode/
.idea/
.DS_Store
```

### Verify .gitignore

Check that .gitignore contains:
```bash
cat .gitignore
```

Should exclude:
- `node_modules/`
- `.env` files
- `dist/` folder
- IDE folders
- OS files

### Create GitHub Pages Branch (Optional)

For GitHub Pages deployment:

```bash
git checkout --orphan gh-pages
git reset --hard
git commit --allow-empty -m "Initial gh-pages branch"
git push origin gh-pages
git checkout main
```

### Add Deployment Badges (Optional)

Add to README.md after title:

```markdown
[![Deployed on Vercel](https://img.shields.io/badge/Deployed_on-Vercel-black.svg?style=flat-square)](https://your-live-url.vercel.app)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
![React](https://img.shields.io/badge/React-18.2.0-blue.svg)
![Vite](https://img.shields.io/badge/Vite-5.0.8-purple.svg)
```

### GitHub Settings to Configure

#### 1. General
- [x] Make repository public
- [x] Enable discussions
- [x] Allow auto-delete head branches

#### 2. Branches
- Set main as default branch
- Add branch protection rules (optional)

#### 3. Pages (for GitHub Pages deployment)
- Build and deployment: Deploy from a branch
- Branch: gh-pages
- Folder: / (root)

#### 4. Actions (for CI/CD)
- GitHub Actions available for automated testing
- Optional for this project

### Verify Repository Content

```bash
# View files in repository
git ls-files

# Should show:
# src/
# package.json
# README.md
# etc.
```

### Final Verification Checklist

- [ ] Repository created on GitHub
- [ ] Local repo initialized with `git init`
- [ ] Remote added with `git remote add origin`
- [ ] All files committed with `git add .`
- [ ] Initial commit pushed with `git push -u origin main`
- [ ] .gitignore properly configured
- [ ] node_modules/ NOT included in repo
- [ ] README.md visible on GitHub
- [ ] License file added (optional)
- [ ] GitHub Pages configured (if using)
- [ ] Vercel/Netlify connected to GitHub (for auto-deployment)

### GitHub Repository URL

Once created, your repository will be available at:
```
https://github.com/yourusername/veyora-shopping
```

### Share Your Repository

**Portfolio Links:**
```markdown
- GitHub: https://github.com/yourusername/veyora-shopping
- Live Demo: https://your-live-url.vercel.app
- LinkedIn: Add project to profile
- Portfolio Website: Link to live demo
```

### Future GitHub Operations

#### Add Updates
```bash
git add .
git commit -m "Fix: Describe change"
git push origin main
```

#### Create Branches for Features
```bash
git checkout -b feature/new-feature
# Make changes
git add .
git commit -m "feat: Add new feature"
git push origin feature/new-feature
# Create Pull Request on GitHub
```

#### Sync with Remote
```bash
git pull origin main
```

---

## Repository Statistics

After first push, GitHub will show:
- **1,281 lines** of code
- **25 source files**
- **0 dependencies** (everything built from scratch)
- **100% open source**

---

## GitHub Best Practices

1. **Meaningful Commit Messages**
   - Use: "feat: Add product details page"
   - Not: "Update stuff"

2. **Regular Commits**
   - Small, logical changes
   - Not one huge commit

3. **Branch Naming**
   - feature/feature-name
   - bugfix/bug-name
   - docs/documentation-update

4. **README Quality**
   - Clear overview
   - Installation steps
   - Usage examples
   - Technology list

5. **License**
   - Add LICENSE file (MIT recommended)
   - Specify in README

---

## Connecting Deployment Platform

### Vercel
1. Go to vercel.com
2. Click "Import Project"
3. Select GitHub repository
4. Click "Deploy"
5. Automatic deployments on push

### Netlify
1. Go to app.netlify.com
2. Click "New site from Git"
3. Select GitHub
4. Choose repository
5. Click "Deploy site"

---

## Private Repository (Optional)

If you want to keep it private initially:

```bash
# During creation, select "Private"
# Later change:
# GitHub Settings → Visibility → Change to Public
```

---

## Troubleshooting GitHub Push

### Credentials Error
```bash
git config --global user.email "your@email.com"
git config --global user.name "Your Name"
```

### SSL Certificate Error
```bash
git config --global http.sslVerify false
```

### Branch Already Exists
```bash
git branch -D main  # Delete local
git checkout -b main  # Create new
git push -u origin main  # Push
```

### Large Files Error
Git has 100MB limit per file. If error:
```bash
git lfs install
git lfs track "*.zip"
git add .gitattributes
git add your-file.zip
git commit -m "Add large file"
git push
```

---

**GitHub Setup: ✅ READY**

Follow the steps above to push your project to GitHub!
